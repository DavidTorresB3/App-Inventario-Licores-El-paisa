package Usuarios;

public class Worker extends Usuario {
    public Worker(String nombre, String correo) {
        super(nombre, correo);
    }

    public void realizarTarea() {
        System.out.println(nombre + " está realizando una tarea.");
    }
}
