package Usuarios;

public class Admin extends Usuario {
    public Admin(String nombre, String correo) {
        super(nombre, correo);
    }

    public void gestionarSistema() {
        System.out.println(nombre + " está gestionando el sistema.");
    }
}
