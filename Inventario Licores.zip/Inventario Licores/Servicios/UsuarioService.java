package Servicios;

import Usuarios.Usuario;

import java.util.ArrayList;
import java.util.List;

public class UsuarioService {
    private List<Usuario> usuarios;

    public UsuarioService() {
        usuarios = new ArrayList<>();
    }

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
        System.out.println("Usuario agregado: " + usuario.nombre);
    }

    public void listarUsuarios() {
        for (Usuario u : usuarios) {
            u.mostrarInfo();
            System.out.println("------------------");
        }
    }
}
