import Servicios.UsuarioService;
import Usuarios.Admin;
import Usuarios.Worker;

public class AppMain {
    public static void main(String[] args) {
        UsuarioService servicio = new UsuarioService();

        Admin admin = new Admin("Laura", "laura@correo.com");
        Worker worker = new Worker("Carlos", "carlos@correo.com");

        servicio.agregarUsuario(admin);
        servicio.agregarUsuario(worker);

        System.out.println("\nLista de usuarios:");
        servicio.listarUsuarios();

        admin.gestionarSistema();
        worker.realizarTarea();
    }
}
