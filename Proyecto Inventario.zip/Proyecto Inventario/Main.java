import controladores.Director;
import controladores.InventarioControlador;
import controladores.LoginControlador;
import repositorio.UsuarioRepositorio;
import repositorio.UsuarioRepositorioImpl;
import servicio.InventarioServicio;
import servicio.UsuarioServicio;

public class Main {
    public static void main(String[] args) {

    // 1. Crear repositorios
    UsuarioRepositorio usuarioRepositorio = new UsuarioRepositorioImpl();

        // 2. Crear servicios
        UsuarioServicio usuarioServicio = new UsuarioServicio(usuarioRepositorio);
        InventarioServicio inventarioServicio = new InventarioServicio();

    // 3. Crear controladores
    Director usuarioControlador = new Director(usuarioServicio);
    LoginControlador loginControlador = new LoginControlador(usuarioServicio);
    InventarioControlador inventarioControlador = new InventarioControlador(inventarioServicio);

        // 4. Crear algunos usuarios
        usuarioControlador.crearUsuario("juan", "ADMIN", "1234");
        usuarioControlador.crearUsuario("maria", "EMPLEADO", "abcd");

        // 5. Probar login
        loginControlador.iniciarSesion("juan", "1234");
        loginControlador.iniciarSesion("maria", "abcd");
        loginControlador.iniciarSesion("juan", "xxxx"); // prueba fallida

        // 6. Probar inventario
        inventarioControlador.registrarIngreso("Aguardiente", 20);
        inventarioControlador.registrarSalida("Ron", 10);
        inventarioControlador.registrarDevolucion("Whisky", 5);

        System.out.println("Sistema funcionando correctamente.");
    }
}
    

