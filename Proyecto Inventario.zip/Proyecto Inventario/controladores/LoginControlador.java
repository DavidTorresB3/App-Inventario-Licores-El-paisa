package controladores;

import modelos.Usuario;
import servicio.UsuarioServicio;

public class LoginControlador {

  private UsuarioServicio usuarioServicio;

    public LoginControlador(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

    public boolean iniciarSesion(String usuario, String password) {
        Usuario u = usuarioServicio.login(usuario, password);

        if (u != null) {
            System.out.println("Inicio de sesión exitoso");
            return true;
        }

        System.out.println("Credenciales incorrectas");
        return false;
    }
}