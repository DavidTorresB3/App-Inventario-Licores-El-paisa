package controladores;

import servicio.UsuarioServicio;

public class Director {
    private UsuarioServicio usuarioServicio;

    public Director(UsuarioServicio usuarioServicio) {
        this.usuarioServicio = usuarioServicio;
    }

   public void crearUsuario(String usuario, String rol, String password) {
    usuarioServicio.crearUsuario(usuario, rol, password);
}
    

    public void eliminarUsuario(String usuario) {
        usuarioServicio.eliminarUsuario(usuario);
    }
}
