package controladores;


import servicio.InventarioServicio;

public class InventarioControlador {
    
    private InventarioServicio inventarioServicio;

    public InventarioControlador(InventarioServicio inventarioServicio) {
        this.inventarioServicio = inventarioServicio;
    }

    public void registrarIngreso(String nombre, int cantidad) {
        inventarioServicio.registrarIngreso(nombre, cantidad);
    }

    public void registrarSalida(String nombre, int cantidad) {
        inventarioServicio.registrarSalida(nombre, cantidad);
    }

    public void registrarDevolucion(String nombre, int cantidad) {
        inventarioServicio.registrarDevolucion(nombre, cantidad);
    }
}

