package modelos;

public class Admin extends Usuario {
    public Admin(String usuario, String password) {
        super(usuario, password);
    }
}