package modelos;

public class Empleado extends Usuario {
    public Empleado(String usuario, String password) {
        super(usuario, password);
    }
}