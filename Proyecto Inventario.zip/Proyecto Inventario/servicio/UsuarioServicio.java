package servicio;

import java.util.List;
import modelos.Admin;
import modelos.Empleado;
import modelos.Usuario;
import repositorio.UsuarioRepositorio;

public class UsuarioServicio {

    private UsuarioRepositorio usuarioRepositorio;

    public UsuarioServicio(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }

    public Usuario login(String usuario, String contrasena) {
        return usuarioRepositorio.buscarPorUsuarioYContrasena(usuario, contrasena);
    }

    public List<Usuario> obtenerTodos() {
        return usuarioRepositorio.obtenerTodosLosUsuarios();
    }

    public void crearUsuario(String usuario, String rol, String password) {
        Usuario u;
        if ("ADMIN".equalsIgnoreCase(rol)) {
            u = new Admin(usuario, password);
        } else {
            u = new Empleado(usuario, password);
        }
        usuarioRepositorio.guardarUsuario(u);
    }

    public void eliminarUsuario(String usuario) {
        usuarioRepositorio.eliminarUsuario(usuario);
    }
}
