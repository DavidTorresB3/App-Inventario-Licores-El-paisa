package servicio;

public class InventarioServicio {
     public void registrarIngreso(String nombre, int cantidad) {
        System.out.println("Ingreso de producto: " + nombre + " cantidad: " + cantidad);
    }

    public void registrarSalida(String nombre, int cantidad) {
        System.out.println("Salida de producto: " + nombre + " cantidad: " + cantidad);
    }

    public void registrarDevolucion(String nombre, int cantidad) {
        System.out.println("Devolución de producto: " + nombre + " cantidad: " + cantidad);
    }
}