package repositorio;

import java.util.List;
import modelos.Usuario;

public interface UsuarioRepositorio {
    Usuario buscarPorUsuarioYContrasena(String usuario, String contrasena);
    List<Usuario> obtenerTodosLosUsuarios();
    void guardarUsuario(Usuario usuario);
    void eliminarUsuario(String usuario);
}