package repositorio;

import java.util.ArrayList;
import java.util.List;
import modelos.Usuario;

public class UsuarioRepositorioImpl implements UsuarioRepositorio {

    private List<Usuario> usuarios = new ArrayList<>();

    @Override
    public Usuario buscarPorUsuarioYContrasena(String usuario, String contrasena) {
        for (Usuario u : usuarios) {
            if (u.getUsuario().equals(usuario) &&
                u.getPassword().equals(contrasena)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarios;
    }

    @Override
    public void guardarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    @Override
    public void eliminarUsuario(String usuario) {
        Usuario toRemove = null;
        for (Usuario u : usuarios) {
            if (u.getUsuario().equals(usuario)) {
                toRemove = u;
                break;
            }
        }
        if (toRemove != null) {
            usuarios.remove(toRemove);
        }
    }
}